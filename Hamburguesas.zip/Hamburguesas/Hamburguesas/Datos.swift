//
//  Datos.swift
//  Hamburguesas
//
//  Created by Alejandro Martinez Montero on 28/11/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import Foundation


class ColeccionDePaises {
    let paises: [String] = ["Alemania", "Espanha", "Mexico", "Inglaterra", "Escocia", "Peru", "Francia", "Belgica", "Estados Unidos", "Grecia", "Japon", "China", "Argentina", "Brasil", "Portugal", "India", "Irlanda", "Finlandia", "Noruega", "Rusia", "Venezuela"]
    
    
    func obtenPais() -> String {
        let randomNumber = Int(arc4random()) % paises.count
        
        return paises[randomNumber]
    }
}


class ColeccionDeHamburguesa {
    let hamburguesas: [String] = ["Cheeseburger", "Double Cheeseburger", "Bacon Burger", "Double bacon burger", "Quarter pound burger", "Chicken burger", "Fish burger", "Pork burger", "Double bacon cheeseburger", "triple burger", "double chicken burgegr", "Double fish burger", "Veggie Burger", "Veggie burger double Cheese", "Chedar bacon burger", "Tofu burger", "turkey burger", "Double chedar turkey burger", "Triple cheese burger", "1 kg burger"]
    
    
    func obtenHamburguesa() -> String {
        let randomNumber = Int(arc4random()) % hamburguesas.count
        
        return hamburguesas[randomNumber]
    }
}
