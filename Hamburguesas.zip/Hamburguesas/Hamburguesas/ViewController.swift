//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Alejandro Martinez Montero on 28/11/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var pais: UILabel!
    @IBOutlet weak var hamburguesa: UILabel!
    
    var country = ColeccionDePaises()
    var burger = ColeccionDeHamburguesa()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func changeCountryAndBurger(_ sender: Any) {
        pais.text = country.obtenPais()
        hamburguesa.text = burger.obtenHamburguesa()
    }
    
}

