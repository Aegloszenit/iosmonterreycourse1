//
//  TypeInterfaceController.swift
//  pizzaChooserAppWatchOS WatchKit Extension
//
//  Created by Alejandro Martinez Montero on 24/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import WatchKit
import Foundation


class TypeInterfaceController: WKInterfaceController {

    var typeOfPizza: [String] = ["Delgada", "Crujiente", "Gruesa"]
    var sizeResultPizza: String = ""
    var typeResultPizza: String = "Delgada"
    @IBOutlet var typeLabel: WKInterfaceLabel!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        let sizeData = context as! ValuesOfPizza
        sizeResultPizza = sizeData.sizePizza
        print("\(sizeData.sizePizza)")
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func typeSliderAction(_ value: Float) {
        typeLabel.setText(typeOfPizza[Int(value)])
        typeResultPizza = typeOfPizza[Int(value)]
    }
    @IBAction func nextTypeAction() {
        let objectPizza = ValuesOfPizza(sizeP: sizeResultPizza, typeP: typeResultPizza, cheeseP: "", extraP: ["","","","",""])
        pushController(withName: "TypeControllerPizza", context: objectPizza)
    }
}
