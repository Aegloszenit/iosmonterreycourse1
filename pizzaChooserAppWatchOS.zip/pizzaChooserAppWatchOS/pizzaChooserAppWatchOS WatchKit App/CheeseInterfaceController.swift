//
//  CheeseInterfaceController.swift
//  pizzaChooserAppWatchOS WatchKit Extension
//
//  Created by Alejandro Martinez Montero on 24/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import WatchKit
import Foundation


class CheeseInterfaceController: WKInterfaceController {

    var cheesePizza: [String] = ["Sin queso", "Mozarella", "Cheedar", "Parmesano"]
    var sizePizza: String = ""
    var typePizzaString: String = ""
    var cheesePizzaString: String = "Sin queso"
    @IBOutlet var cheeseLabel: WKInterfaceLabel!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        let typePizza = context as! ValuesOfPizza
        sizePizza = typePizza.sizePizza
        typePizzaString = typePizza.typePizza
        
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func cheeseSliderAction(_ value: Float) {
        cheeseLabel.setText(cheesePizza[Int(value)])
        cheesePizzaString = cheesePizza[Int(value)]
    }
    
    
    @IBAction func cheeseAction() {
        let cheeseObject = ValuesOfPizza(sizeP: sizePizza, typeP: typePizzaString, cheeseP: cheesePizzaString, extraP: ["","","","",""])
        pushController(withName: "CheeseControllerSender", context: cheeseObject)
    }
    
}
