//
//  TamanhoInterfaceController.swift
//  pizzaChooserAppWatchOS WatchKit Extension
//
//  Created by Alejandro Martinez Montero on 24/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import WatchKit
import Foundation


class TamanhoInterfaceController: WKInterfaceController {
    
    var sizeOfPizza: [String] = ["Pequeña", "Mediana", "Grande"]
    var resultSizePizza: String = "Pequeña"

    @IBOutlet var sliderSizePizza: WKInterfaceSlider!
    @IBOutlet var sizeLabel: WKInterfaceLabel!
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func sliderSizeAction(_ value: Float) {
        
        sizeLabel.setText(sizeOfPizza[Int(value)])
        resultSizePizza = sizeOfPizza[Int(value)]

    }
    @IBAction func sizeAction() {
                let valuesPizzaSize = ValuesOfPizza(sizeP: resultSizePizza, typeP: "", cheeseP: "", extraP: ["","","","",""])
                pushController(withName: "SizePizzaController", context: valuesPizzaSize)
    }
}
