//: Playground - noun: a place where people can play

import UIKit

enum velocidades: Int {
    case apagado = 0
    case velocidad_baja = 20
    case velocidad_media = 50
    case velocidad_alta = 120
    
    init(velocidadInicial: velocidades) {
        self = velocidadInicial
    }
    
}


class Auto {
    var velocidad: velocidades
    
    init() {
       self.velocidad = .apagado
    }
    
    
    func cambioDeVelocidad()-> (actual: Int, velocidadEnCadena: String) {
        var leyenda: String
        switch velocidad {
        case .apagado:
            self.velocidad = .velocidad_baja
            leyenda = "Velocidad baja"
        case .velocidad_baja:
            self.velocidad = .velocidad_media
            leyenda = "Velocidad media"
        case .velocidad_media:
            self.velocidad = .velocidad_alta
            leyenda = "Velocidad alta"
        case .velocidad_alta:
            self.velocidad = .velocidad_media
            leyenda = "Velocidad media"
        default:
            print("error")
        }
        
        return (self.velocidad.rawValue, leyenda)
    }

}



var auto = Auto()
print("\(auto.velocidad.rawValue), \(auto.velocidad) ")
for item in 0...20 {
    auto.cambioDeVelocidad()
    print("\(auto.velocidad.rawValue), \(auto.velocidad) ")
}



