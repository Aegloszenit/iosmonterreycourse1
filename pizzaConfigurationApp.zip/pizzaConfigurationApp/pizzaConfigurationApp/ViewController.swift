//
//  ViewController.swift
//  pizzaConfigurationApp
//
//  Created by Alejandro Martinez Montero on 9/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var result: [String] = [""]
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var sizeSegmentedOption: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        continueButton.isUserInteractionEnabled = false
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let value = sizeSegmentedOption.selectedSegmentIndex
        result[0] = sizeSegmentedOption.titleForSegment(at: value)!
        let nextView = segue.destination as! tamanhoViewController
        nextView.pizzaConf = result
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func chooseSizeAction(_ sender: Any) {
        continueButton.isUserInteractionEnabled = true
    }
    
    @IBAction func sizeButtonAction(_ sender: Any) {
        if sizeSegmentedOption.selectedSegmentIndex == -1 {
            
        }
        
        
    }
}

