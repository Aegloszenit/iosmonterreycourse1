//
//  resultsViewController.swift
//  pizzaConfigurationApp
//
//  Created by Alejandro Martinez Montero on 9/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import UIKit

class resultsViewController: UIViewController {

    @IBOutlet weak var tipoLabel: UILabel!
    @IBOutlet weak var quesoLabel: UILabel!
    @IBOutlet weak var tamanhoLabel: UILabel!
    @IBOutlet weak var extrasLabel: UILabel!
    
    var finalResults: [String] = [""]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tamanhoLabel.text = finalResults[0]
        tipoLabel.text = finalResults[1]
        quesoLabel.text = finalResults[2]
        extrasLabel.text = finalResults[3] + finalResults[4] + finalResults[5] + finalResults[6] + finalResults[7]
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tamanhoLabel.text = finalResults[0]
        tipoLabel.text = finalResults[1]
        quesoLabel.text = finalResults[2]
        extrasLabel.text = finalResults[3] + finalResults[4] + finalResults[5] + finalResults[6] + finalResults[7]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func sendPizza(_ sender: Any) {
        let alert = UIAlertController(title: "Enviada", message: "La pizza ha sido pedida a la cocina", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Cerrar", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
