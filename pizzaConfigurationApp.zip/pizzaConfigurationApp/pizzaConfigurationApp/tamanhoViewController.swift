//
//  tamanhoViewController.swift
//  pizzaConfigurationApp
//
//  Created by Alejandro Martinez Montero on 9/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import UIKit

class tamanhoViewController: UIViewController {

    var pizzaConf: [String] = [""]
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var typePizzaChooser: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        continueButton.isUserInteractionEnabled = false
        pizzaConf.append("")

    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let value = typePizzaChooser.selectedSegmentIndex
        pizzaConf[1] = typePizzaChooser.titleForSegment(at: value)!
        let nextView = segue.destination as! quesoViewController
        nextView.pizzaConf = pizzaConf
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func typeChooserAction(_ sender: Any) {
        continueButton.isUserInteractionEnabled = true
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
