//
//  quesoViewController.swift
//  pizzaConfigurationApp
//
//  Created by Alejandro Martinez Montero on 9/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import UIKit

class quesoViewController: UIViewController {

    var pizzaConf: [String] = ["", ""]
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var cheeseTypeChooser: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        continueButton.isUserInteractionEnabled = false
        print("\(pizzaConf)")
        pizzaConf.append("")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let value = cheeseTypeChooser.selectedSegmentIndex
        pizzaConf[2] = cheeseTypeChooser.titleForSegment(at: value)!
        let nextView = segue.destination as! ingredientesViewController
        nextView.results = pizzaConf
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func cheeseTypeUserAction(_ sender: Any) {
        continueButton.isUserInteractionEnabled = true
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
