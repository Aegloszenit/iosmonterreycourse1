//
//  ingredientesViewController.swift
//  pizzaConfigurationApp
//
//  Created by Alejandro Martinez Montero on 9/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import UIKit

class ingredientesViewController: UIViewController {
    var results: [String] = [""]
    @IBOutlet weak var contunueButton: UIButton!
    @IBOutlet weak var jamonSwitch: UISwitch!
    @IBOutlet weak var peperoniSwitch: UISwitch!
    @IBOutlet weak var wurstSwitch: UISwitch!
    @IBOutlet weak var anchoaSwitch: UISwitch!
    @IBOutlet weak var cebollaSwitch: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        contunueButton.isUserInteractionEnabled = false
        print("\(results)")
        results.append("")
        results.append("")
        results.append("")
        results.append("")
        results.append("")
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if jamonSwitch.isOn {
            results[3] = "Jamon "
        }
        if peperoniSwitch.isOn {
            results[4] = "Peperoni "
        }
        if wurstSwitch.isOn {
            results[5] = "Salchicha "
        }
        if anchoaSwitch.isOn {
            results[6] = "Anchoas "
        }
        if cebollaSwitch.isOn {
            results[7] = "Cebollas "
        }
        let nextView = segue.destination as! resultsViewController
        nextView.finalResults = results
        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func jamonIgredientAction(_ sender: Any) {
        if jamonSwitch.isOn {
            contunueButton.isUserInteractionEnabled = true
        }
        else {
            if peperoniSwitch.isOn || wurstSwitch.isOn || anchoaSwitch.isOn || cebollaSwitch.isOn {
                contunueButton.isUserInteractionEnabled = true
            }
            else {
                contunueButton.isUserInteractionEnabled = false
            }
        }
    }
    
    @IBAction func peperoniAction(_ sender: Any) {
        if peperoniSwitch.isOn {
            contunueButton.isUserInteractionEnabled = true
        }
        else {
            if jamonSwitch.isOn || wurstSwitch.isOn || anchoaSwitch.isOn || cebollaSwitch.isOn {
                contunueButton.isUserInteractionEnabled = true
            }
            else {
                contunueButton.isUserInteractionEnabled = false
            }
        }
    }
    
    
    @IBAction func wurstAction(_ sender: Any) {
        if wurstSwitch.isOn {
            contunueButton.isUserInteractionEnabled = true
        }
        else {
            if jamonSwitch.isOn || peperoniSwitch.isOn || anchoaSwitch.isOn || cebollaSwitch.isOn {
                contunueButton.isUserInteractionEnabled = true
            }
            else {
                contunueButton.isUserInteractionEnabled = false
            }
        }
    }
    
    @IBAction func anchoaAction(_ sender: Any) {
        if anchoaSwitch.isOn {
            contunueButton.isUserInteractionEnabled = true
        }
        else {
            if jamonSwitch.isOn || peperoniSwitch.isOn || wurstSwitch.isOn || cebollaSwitch.isOn {
                contunueButton.isUserInteractionEnabled = true
            }
            else {
                contunueButton.isUserInteractionEnabled = false
            }
        }
    }
    
    @IBAction func cebollaAction(_ sender: Any) {
        if cebollaSwitch.isOn {
            contunueButton.isUserInteractionEnabled = true
        }
        else {
            if jamonSwitch.isOn || peperoniSwitch.isOn || wurstSwitch.isOn || anchoaSwitch.isOn {
                contunueButton.isUserInteractionEnabled = true
            }
            else {
                contunueButton.isUserInteractionEnabled = false
            }
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
