//: Playground - noun: a place where people can play

import UIKit

for imy_item in 0...100 {
    // if statement for checking modulo 5
    if imy_item % 5 == 0 {
        print("Bingo")
    }
    // if statement for par and impar numbers
    if imy_item % 2 == 0 {
        print("Par")
    }
    else {
        print("Impar")
    }
    // if statement for numbers between 30 and 40 inclusive
    if imy_item >= 30 && imy_item <= 40 {
        print("\(imy_item) Viva Swift")
    }
}
