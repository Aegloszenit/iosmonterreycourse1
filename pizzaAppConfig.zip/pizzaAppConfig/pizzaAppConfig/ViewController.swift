//
//  ViewController.swift
//  pizzaAppConfig
//
//  Created by Alejandro Martinez Montero on 2/12/17.
//  Copyright © 2017 Alejandro Martinez Montero. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tamanhoPizza: UISegmentedControl!
    @IBOutlet weak var masaPizza: UISegmentedControl!
    @IBOutlet weak var quesoPizza: UISegmentedControl!
    @IBOutlet weak var jamonSwitch: UISwitch!
    @IBOutlet weak var salchichaSwitch: UISwitch!
    @IBOutlet weak var peperoniSwitch: UISwitch!
    @IBOutlet weak var aceitunaSwitch: UISwitch!
    @IBOutlet weak var anchoaSwitch: UISwitch!
    @IBOutlet weak var orderPizza: UIButton!
    var results: [String] = ["", "", "", "", "", "", "", "", ""]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        orderPizza.isUserInteractionEnabled = false
        results[2] = "sin queso"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let nextView = segue.destination as! ConfirmViewController
        nextView.myResults = results
    }

    @IBAction func oderPizzaAction(_ sender: Any) {

    }
    @IBAction func selectSizeSegment(_ sender: Any) {
        
        let value = tamanhoPizza.selectedSegmentIndex
        results[0] = tamanhoPizza.titleForSegment(at: value)!
        if masaPizza.selectedSegmentIndex == -1 {

        }
        else {

            orderPizza.isUserInteractionEnabled = true
        }
        
    }
    
    @IBAction func selectTypeSegment(_ sender: Any) {
        let value = masaPizza.selectedSegmentIndex
        results[1] = masaPizza.titleForSegment(at: value)!
        if tamanhoPizza.selectedSegmentIndex == -1 {
            
        }
        else {
            orderPizza.isUserInteractionEnabled = true
        }
        
    }
    
    @IBAction func selectCheeseSegment(_ sender: Any) {
        
        let value = quesoPizza.selectedSegmentIndex
        results[2] = quesoPizza.titleForSegment(at: value)!
    }
    
    @IBAction func jamonSwitchoption(_ sender: Any) {
        if jamonSwitch.isOn {
            results[3] = "Jamon"
        }
        else {
            results[3] = ""
        }
    }
    
    
    @IBAction func salchichaSiwtchoption(_ sender: Any) {
        if salchichaSwitch.isOn {
            results[4] = "Salchichas"
        }
        else {
            results[4] = ""
        }
    }
    
    
    @IBAction func peperoniSwitchOption(_ sender: Any) {
        if peperoniSwitch.isOn {
            results[5] = "Peperoni"
        }
        else {
            results[5] = ""
        }
    }
    
    @IBAction func aceitunaSwitchoption(_ sender: Any) {
        if aceitunaSwitch.isOn {
            results[6] = "Aceituna"
        }
        else {
            results[6] = ""
        }
    }
    
    @IBAction func acnhoaSwitchOption(_ sender: Any) {
        if anchoaSwitch.isOn {
            results[7] = "Anchoa"
        }
        else {
            results[7] = ""
        }
    }
    
}

